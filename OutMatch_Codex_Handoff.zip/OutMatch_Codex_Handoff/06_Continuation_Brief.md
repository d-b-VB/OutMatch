# OutMatch Continuation Brief

## Current direction
Move OutMatch from conversational prototypes into a durable repository capable of:
- hundreds of competitors;
- several hundred thousand to millions of exact simulated games;
- reproducible evolutionary campaigns;
- human-vs-AI replay analysis.

## Immediate priorities

### 1. Establish one exact rules engine
Implement the canonical specification and comprehensive tests.

### 2. Eliminate obvious tactical nonsense
Human play exposed the key example: an earlier Scipio sent Cavalry forward to be captured pointlessly on move one.

Add:
- opening sanity;
- exact immediate opponent reply;
- whole-turn search.

Then reevaluate all major named lineages.  Do not assume historical rankings survive.

### 3. Preserve strategy identities
Sophistication should be layered on top of a general's doctrine.  A “smarter Hannibal” should still resemble Hannibal.

### 4. Scale the tournament runner
Target first:
- 300 generals;
- stratified mixed ecology;
- staged screening;
- color balancing;
- parallel execution;
- persistent results.

Then scale to 500+.

### 5. Continue evolutionary ecology
Every generation should include:
- champions;
- several Scipionic descendants/crosses;
- Hannibalic and Parthian controls;
- Paullus/anti-Scipio descendants;
- Emu;
- Fabius-Khan;
- middle-tier Ackbar/Narses/Genghis-like controls;
- weak fodder;
- failed crosses;
- fresh wild cards;
- occasional historians and dunce historians;
- revised Sun Tzu students.

### 6. Hunt sophisticated Scipio
Do not optimize against the known-blundering version.
Create a reply-aware “Scipio the Wiser” baseline first, then breed:
- intentional assassins;
- mutations of Paullus;
- Surenid counters;
- Emu-derived counters;
- random screened hunters;
- crossbreeds between killers and unrelated generalists.

### 7. Sun Tzu Academy revision
Sun's first universal rules sometimes harmed strong siblings.

New rule:
No axiom is “universal” until trained variants outperform untrained siblings across multiple unrelated lineages.

For every failed academy student:
- collect decision disagreements;
- attribute them to specific axiom(s);
- amend rules;
- retest all students.

### 8. Continue wild barbarian discovery
Use broad wild-card randomization every generation.  Major prior discoveries came from wild policies.

### 9. Build human-play logging
The browser must:
- choose opponent;
- choose human Red/Blue;
- save multiple games locally;
- share compact replay codes via native Share;
- support copy/text fallback;
- export all;
- import/replay logs.

Recommended opponents for human testing:
Top/interesting:
- Hannibal
- sophisticated Scipio
- Paullus
- Surena
- Emu
- Fabius-Khan

Mid:
- Narses
- Ackbar
- Genghis

Bad:
- Grievous
- Crassus
- Varro

### 10. Human-derived Macedonian line
Reserve Macedonian names.

When sufficient human games exist:
- create **Philip** from observed human play;
- have **Aristotle** analyze the archive and repeatedly revise the next generation;
- compare Philip and Aristotle descendants against the full ecology;
- explicitly identify strategies humans introduce that the existing genome/search space failed to discover.

---

# Known historical insights to preserve

## Threat saturation
Risk is closer to enemy maximum captures next turn than number of threatened pieces.

## False flanks
Earlier Agrippan/Parthian policies could be induced into bad positional responses by apparent flanks.  Flank perception must include reachability, target value, route, and center cost.

## Stable losing positions
“Safe” and unthreatened can still be strategically lost if the position preserves a small disadvantage forever.

## Strong strategies can resist sensible improvement
Hannibal and Scipio variants have sometimes been harmed by historian/Sun overlays.  This is evidence that optimization layers can destroy useful eccentricity.

## Crossbreeding failures are valuable
Retain poor lines and failed crosses as genetic material and controls.

## Wild cards are essential
Do not narrow the genome space to current theory.

---

# Open research questions
- What exact opening moves are strong under reply-aware search?
- Is Hannibal still elite against sophisticated search?
- Which Scipio characteristics survive after fixing the Cavalry blunder?
- Why does Emu work when it works?
- Can Paullus remain anti-Scipio against a tactically sane Scipio?
- What is the best exact kill-capacity model under sequential activations?
- Does opponent modeling improve play after whole-turn search is introduced?
- What Academy axioms survive sibling testing?
- How often do historians infer backwards causality?
- Which human decisions fall outside the current strategic genome?

## First recommended Codex experiment
1. Implement exact rules and tests.
2. Port 12 representative generals.
3. Add immediate-reply tactical sanity.
4. Run old vs reply-aware siblings on a stratified field.
5. Produce a report showing which rankings and behaviors changed.
6. Only then begin the 300-general evolutionary campaign.

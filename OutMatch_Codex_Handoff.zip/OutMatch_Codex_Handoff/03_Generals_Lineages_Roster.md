# OutMatch Generals and Lineages

**Status: living roster.  Names identify strategic policies/lineages, not fixed game rules.**

## 1. Naming rule
Macedonian names are reserved for the human-derived line.
- Philip: first-generation general modeled on human play.
- Aristotle: analyst/trainer that continually updates the second human-derived generation.
Do not spend Macedonian names on unrelated experiments.

---

# 2. Major historical lineages

## Agrippan family
Representative names:
- Agrippa
- Agrippa II
- Belisarius
- Narses
- Maurice
- Polybius (historian descendant)

Characteristics:
- disciplined layered/screened combined arms;
- danger awareness and support;
- tends to convert real advantages well;
- historically vulnerable to sterile slightly-losing states and some false-flank responses;
- useful genetic stock even when no longer meta champion.

Marc Antony was originally bred specifically to hunt Agrippa.  Crossbreeding later made some Antony descendants competent generalists.

## Parthian / Surenid family
Representative names:
- Surena
- Surena II/III/IV
- Surenid Horse Archer
- Shapur
- Shapur II
- Shapur the Great
- Mithridates
- Xenophon (historian experiment)

Characteristics:
- Archer-heavy screens and kiting;
- patience and ranged preservation;
- later descendants added flank/mobility;
- historically generated one of the strongest early exact-board bloodlines.

Ventidius descendants were bred as anti-Parthian specialists.

## Hannibalic family
Origin:
- The policy was discovered as `Wildcard A`, then renamed **Hannibal**.

Characteristics:
- low conventional danger/aggression scores in some versions;
- strong Cavalry tendency plus balance/ratio corrections;
- often refuses apparently obvious opportunities;
- unusually robust against “smart” interventions;
- historian and opponent-model overlays have sometimes made Hannibal worse;
- human testing found Hannibal more interesting and difficult than the original Scipio implementation.

Hannibal illustrates why wild cards must never disappear from the population.

## Scipionic family
Origin:
- A fresh random strategy (`Wildcard G` in one experimental series) was renamed **Scipio Africanus** after it proved unusually strong and anti-Hannibal.

Descendants/related:
- Scipio II
- Scipio Aemilianus
- Scipio Nasica
- Scipio IV
- Scipio the Wiser
- numerous Scipio crossbreeds

Important caveat:
A browser/human-play observation found an earlier Scipio routinely sent Cavalry out to die pointlessly on move one.  This means old aggregate rankings overestimated strategic sophistication.  Future Scipionic engines must include tactical sanity/reply awareness.

Anti-Scipio lines:
- Paullus / Paullus 2 and descendants
- Surena often performed well against Scipio
- Emu unexpectedly performed well in some anti-Scipio testing
- additional assassins should continue to be bred against sophisticated Scipio descendants, not only the tactically flawed original.

## Fabius-Khan family
Origin:
- cross between Genghis-like mobility and Fabius-like preservation.

Characteristics:
- mobility without pure recklessness;
- strong example of productive cross-pollination between almost opposite strategic instincts;
- descendants repeatedly remained competitive in mixed fields.

## Mongol family
Representative names:
- Genghis
- Kublai Khan
- Kublai the Reformer
- Kublai the Chronicler

Characteristics:
- Cavalry-heavy, wide, flank-oriented;
- many disciplined descendants underperformed;
- historical-learning experiments sometimes improved the family;
- useful as a distinct outgroup even when low/mid tier.

## Ackbar family
Characteristics:
- support-heavy defensive/combined-arms play;
- often a respectable middle-tier control;
- several useful crosses originated from Ackbar;
- should remain in tournament ecologies even when not champion.

## Reckless / Grievous family
Representative:
- Grievous
- Grievous the Penitent
- Grievous the Mythmaker (dunce-historian concept)

Characteristics:
- extreme aggression/charge;
- useful fodder and outgroup;
- historian intervention sometimes improved it by teaching it to stop charging after falling badly behind.

## Emu
Keep the name **Emu**.

Characteristics:
- intentionally irregular, evasive, feint-heavy, Cavalry-inclined;
- often loose/wide;
- opportunistic committed charges;
- surprisingly strong in several experimental runs;
- strategically valuable because it does not fit established historical schools.

---

# 3. Specialist / assassin traditions

## Marc Antony
Original purpose: beat Agrippa even if it loses to everyone else.
Over generations, some Antony descendants became broad generalists.

## Ventidius
Original purpose: beat Surena/Parthians.
A successful lesson was not merely “chase the kiting Archers,” but induce their response and attack the structure supporting the kite.

## Paullus
Current anti-Scipio tradition.
Should be tested specifically against **reply-aware/sophisticated Scipio**, not a version with the opening Cavalry blunder.

## Corbulo
Previously emerged as a predator of a Ventidius assassin line.

## Assassin design rule
An assassin's fitness may be dominated by its designated target:
- 70-90% weight against target/family;
- small weight against general field only to avoid total incoherence.
Do not discard a 35% overall general that is 80% against a dominant champion.

---

# 4. Academy and historian classes

## Sun Tzu Academy
A meta-school that attempts to extract broadly useful axioms from all games.

Version 1 overgeneralized rules such as “preserve advantage by reducing variance” and sometimes made elite lineages worse.  Sun's doctrines must therefore update empirically.

Future Academy procedure:
1. Create educated sibling and uneducated sibling from same parent.
2. Run on identical stratified field.
3. Analyze every disagreement where the educated sibling chose differently.
4. Identify which axiom caused the divergence.
5. Amend or qualify the axiom globally if it repeatedly produces worse outcomes.
6. Preserve lineage-specific successful behavior unless evidence against it is strong.

## Historians
A historian studies its own lineage's wins/losses and identifies:
- reliably winning states;
- nearly hopeless states;
- transitions that precede collapse;
- composition/geometry associated with recovery.

Create historians only when enough wins and losses exist to justify analysis.

## Dunce historians
Deliberately learn an opposite or naïve lesson from the same family history.
Purpose:
- test causal assumptions;
- preserve “bad” behaviors that may secretly be essential;
- expose historian overfitting.

A dunce historian beating its sensible sibling is evidence that the historical interpretation may be wrong.

---

# 5. Middle-tier and fodder controls

Keep respectable controls:
- Ackbar
- Fabius
- Genghis or current Mongol
- a stable Agrippan
- a stable Parthian
- a stable Hannibalic representative

Keep weak controls/fodder:
- Crassus
- Varro
- deliberately reckless or passive policies
- failed crosses

Why retain fodder:
- catches catastrophic regressions;
- measures whether a “specialist” can play basic OutMatch;
- provides ecological variety;
- weak ancestry may become useful in future crosses.

---

# 6. Wild cards
Every generation should include fresh randomly generated policies.

Do not constrain randoms to “reasonable” doctrine.  Randoms have produced major strategic discoveries.

Suggested minimum:
- 5-15% of each generation fresh wild cards.
- Preserve genomes of all unusual performers.
- Preserve at least some spectacular failures for future crossbreeding.
- Rename only after repeated validation.

Possible “barbarian” naming pool for strong wild discoveries:
- Alaric
- Attila
- Arminius
- Boudica
- Vercingetorix
- Genseric/Gaiseric
- Odoacer
- Totila
- Alboin
- Civilis
- Boiorix

Avoid Macedonian names for these.

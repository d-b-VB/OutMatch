# Historical Evidence

These files are retained for context, regression investigation, and lineage archaeology.

They are **not authoritative game rules**.  Many were generated under older greedy evaluators, approximate threat logic, small pairwise samples, or the former project name UpKeep.

Use them to:
- recover named policies and rankings;
- identify interesting old matchups;
- compare new engines against old behavior;
- preserve historical claims.

Do not:
- treat old win rates as comparable across engine versions without re-running;
- copy an old browser rule over the canonical spec;
- assume an old AI evaluator was tactically sane.

# OutMatch: Canonical Game Specification

**Status: authoritative unless explicitly amended.**

## 1. Board
OutMatch is played on a radius-3 hexagon composed of **37 hexes** using axial coordinates `(q, r)`.  Opposing home bases occupy opposite corner hexes.  In current implementations:
- Red base: `(-3, 0)`
- Blue base: `(3, 0)`

The three-color tiling is visual only and has no game effect.

## 2. Sides and initial army
Two sides: **Red** and **Blue**.

Each side begins with:
- 1 Pikeman
- 1 Archer
- 1 Cavalry

Current canonical starting placements:
- Red Pikeman `(-2, 0)`
- Red Archer `(-3, 1)`
- Red Cavalry `(-2, -1)`
- Blue Pikeman `(2, 0)`
- Blue Archer `(3, -1)`
- Blue Cavalry `(2, 1)`

Red takes the first turn.

## 3. Objective
A player wins by **eliminating all enemy units**.

Simulation engines may impose a round cap for computational experiments, but this is an adjudication device, not a canonical game rule.  Human-play versions should not silently end on a heuristic score unless a separate draw/turn-limit rule is deliberately added.

## 4. Activation
Each existing unit may activate **once per turn**.

- A newly deployed unit is considered already activated for the turn in which it appears.
- A player may choose to hold a unit; holding consumes that unit's activation.
- Activation order is chosen freely by the player.
- This order matters and should remain part of the strategy.

## 5. Pikeman
- Moves up to **1 adjacent hex**.
- Captures by moving onto an enemy-occupied adjacent hex.
- Cannot move onto a friendly-occupied hex.

### Anti-cavalry stop zone
A cavalry unit **may enter** a hex adjacent to an enemy Pikeman, but once it enters such a hex, its movement ends.

This is a **stop zone**, not an exclusion zone.

Consequences:
- Cavalry may capture an enemy occupying such a hex, but stops there.
- Cavalry may not continue moving through a pike-adjacent hex.
- Do not implement this as “cavalry cannot enter pike zones.”

## 6. Archer
- May move **1 adjacent empty hex**.
- May kill **one adjacent enemy** without moving onto that enemy's hex.
- The shot may occur **before or after the Archer's move**.
- The Archer may therefore:
  - shoot and hold;
  - shoot, then move;
  - move, then shoot;
  - move without shooting;
  - hold without shooting.
- One shot maximum per activation.

Canonical shooting range is **adjacent only (hex distance 1)**.  Some old evaluation code approximated Archer threat at distance 2; that is an AI-analysis bug, not a rule.

## 7. Cavalry
- May move up to **3 hexes** in one activation.
- Captures by entering an enemy-occupied hex; capture ends movement.
- May pass through friendly units.
- May not end on a friendly unit.
- May not pass through an enemy unit.
- Entering a pike stop zone ends movement as described above.

Movement is path-dependent.  Implement legal Cavalry destinations by traversal/BFS, not merely by hex distance.

## 8. Recruitment and deployment
The production cycle is deliberately delayed and partially hidden.

### Odd-numbered rounds: commitment
On rounds 1, 3, 5, ...
- Each player commits to producing **one** unit type: Pikeman, Archer, or Cavalry.
- The player's own commitment is known to that player.
- The opponent's commitment is hidden.
- A player that is able to recruit should commit before ending the turn.

### Following even-numbered round: deployment
On rounds 2, 4, 6, ...
- The committed unit is deployed on an **empty hex adjacent to that player's base**.
- The newly deployed unit cannot activate that turn.

### Blocked deployment
Earlier browser prototypes could soft-lock when every base-adjacent hex was occupied.  The production rule should explicitly handle this.  Recommended canonical behavior for implementation:
- If no legal deployment hex exists, the queued unit remains queued.
- The player may still take and end the turn.
- Deployment is attempted again at the start of the player's next turn before any new commitment.
- A player cannot accumulate multiple queued units; production remains blocked until the pending unit deploys.

If a different solution is adopted, document it and test it explicitly.

## 9. Information
- Board position and existing pieces are public.
- A player's current queued commitment is private to that player until deployment.
- AI code must not inspect the opponent's hidden queue unless running an explicitly omniscient experiment.

## 10. Turn and round sequence
Recommended exact sequence:

1. Start player's turn.
2. If a queued unit exists and a legal deployment hex exists, deploy it and mark it activated.
3. If this is an odd round and no unit is already queued, commit a unit type.
4. Activate existing eligible units in any order, each at most once.
5. End turn.
6. After Blue ends its turn, increment the round number.

## 11. Rules that are NOT canonical
Do not infer these from historical simulation files:
- “Material points” are not a game resource.
- Formations are not enforced states; they are AI preferences.
- Maneuver names are AI vocabulary, not legal actions.
- There is no canonical terrain effect from hex colors.
- There is no base capture victory condition.
- There is no automatic fixed turn cap.
- There is no requirement to move every piece.
- A pike zone is not impassable to Cavalry.

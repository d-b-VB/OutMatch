# OutMatch Evolution and Experimentation Strategy

## 1. Objective
The goal is not to converge quickly on one average “best” general.  The goal is to create an evolving strategic ecology that discovers:
- strong generalists;
- specialists and assassins;
- predators of current champions;
- robust middle-tier styles;
- weird successful strategies;
- useful strategic genes from failed lineages;
- counters to counters;
- human-derived novelties.

---

# 2. Population composition per generation
Each generation should deliberately include several classes.

Recommended starting mix for 300 competitors:
- 20-30 retained elite/generalist parents
- 30-50 champion mutations
- 30-50 crossbreeds among successful lines
- 20-40 crosses involving mid/low/failed lines
- 20-30 target-specific assassins
- 10-20 assassin descendants/counter-assassins
- 10-20 historians / occasional dunce historians (not necessarily every generation)
- 30-60 respectable middle-tier controls
- 20-30 weak/fodder controls
- 30-60 fresh wild cards

Exact proportions should change with computational budget.

---

# 3. Preserve diversity
Never run only “tournaments of champions.”

Every serious field should contain:
- top contenders;
- established mids;
- known spoilers;
- weak controls;
- old/outdated champions;
- specialists;
- random wild cards.

This distinguishes a true generalist from an overfit champion-killer.

---

# 4. Mutation
A mutation may alter:
- recruitment weights;
- counter/balance/ratio parameters;
- danger/aggression/support;
- charge/flank/kite preferences;
- condition thresholds;
- formation mappings;
- maneuver mappings;
- perception thresholds;
- reply-search depth;
- opponent-model confidence;
- historical-learning confidence.

Use a mixture of:
- small local mutations;
- occasional large jumps;
- structural mutations that replace one conditional response;
- perception mutations independent of policy mutations.

Keep exact parent ID, mutation seed, and changed fields.

---

# 5. Cross-pollination
Continue crossing:
- champion × champion;
- champion × specialist;
- champion × mid-tier;
- champion × weak/failure;
- assassin × its target;
- wild card × disciplined lineage;
- defensive × aggressive;
- mobile × static.

Do not reject ugly crosses in advance.  Several productive lines arose from combinations that looked theoretically incoherent.

Crosses should record:
- both parents;
- inheritance rule per field;
- random seed;
- any post-cross mutation.

---

# 6. Assassin programs
For each dominant top performer:
1. Identify repeated losses.
2. Analyze the board states and tactical sequences before those losses.
3. Form explicit hypotheses about exploitable behavior.
4. Hand-design several target-specific policies.
5. Mutate successful target-killers aggressively.
6. Introduce random challengers screened primarily against the target.
7. Cross target-killers with unrelated generalists.
8. Separately measure:
   - target win rate;
   - family-wide target rate;
   - unrelated-field rate.

An assassin need not be a generalist.

When an assassin becomes a dominant generalist, immediately create assassins for the usurper.

---

# 7. Historian program
Historians are occasional descendants, not a compulsory class every generation.

Trigger a historian analysis when a lineage has:
- enough wins and losses;
- repeated comparable states;
- statistically/empirically meaningful differences in eventual outcome.

Analyze:
- unit margin;
- exact composition;
- immediate captures;
- exact enemy kill capacity;
- local numerical superiority;
- support graph;
- center/wings;
- progress/tempo;
- recruitment history;
- state transitions, not only snapshots.

Questions:
- At what point is victory nearly assured?
- What does “hopeless” look like for this family?
- Which quiet states are actually losing traps?
- Which apparent “good conditions” are merely responses to already winning?
- What changes preceded recoveries?

Validate historian changes against an unchanged sibling.

---

# 8. Dunce historian controls
Sometimes generate a descendant that intentionally:
- reinforces the factor the historian suppresses;
- treats a losing correlation as desirable;
- ignores a “lesson”;
- draws a simplistic causal conclusion.

Purpose:
- test whether the historian learned causation or correlation;
- discover counterintuitive strategic dependencies.

---

# 9. Sun Tzu Academy
Sun analyzes **all lineages**, not one family.

## Academy workflow
1. Aggregate games from broad populations.
2. Find recurring strong plays and recurring blunders.
3. Form candidate universal axioms.
4. Apply axioms as a light meta-layer to several different parent lineages.
5. Compare trained child vs untrained sibling on identical fields.
6. Analyze all disagreements.
7. Amend/qualify/discard axioms that underperform.
8. Repeat.

Important lesson already established:
A universal “reduce variance when ahead” principle can harm a lineage whose winning method depends on maintaining tempo.  Academy rules must be conditional.

### Desired form of an axiom
Bad:
“Never expose a piece when ahead.”

Better:
“When ahead, avoid increasing the opponent's maximum next-turn capture capacity unless the move wins material, creates a forcing sequence, or materially increases your own capture capacity/tempo.”

---

# 10. Wild-card program
Fresh wild cards are permanent.

Use broad randomization over:
- recruiting;
- tactical weights;
- formation/maneuver mappings;
- perception thresholds;
- sophistication;
- risk interpretation.

Do not restrict randoms to human-designed “reasonable” regions.

Screen wild cards cheaply, then validate surprises at higher repetitions.

---

# 11. Tournament methodology at scale

A full 300-general round robin has 44,850 pairings.  Ten games per pairing is 448,500 games.

For 500 generals:
- 124,750 pairings;
- 1,247,500 games at ten repetitions.

Use staged selection.

### Stage 0: sanity
Every genome vs:
- 2-4 weak controls;
- basic rule fixtures.
Reject engines/policies that crash or make illegal moves.

### Stage 1: broad screening
2-4 games against a stratified panel or Swiss opponents.

### Stage 2: ecological field
More games against champions, mids, specialists, wilds, and lineage rivals.

### Stage 3: top/specialist validation
High repetitions for:
- top 30-50;
- targeted assassin matchups;
- surprising wild cards;
- contradictory historian results.

### Stage 4: rivalry tests
Fixed color-balanced repeated sets, with confidence intervals.

Do not interpret 0/50/100 from a two-game pairing as reliable.

---

# 12. Fitness should be multi-objective
Track separately:
- broad-field win rate;
- elimination rate;
- target-specific assassin score;
- robustness across colors;
- performance vs top quartile;
- performance vs mids;
- performance vs fodder;
- novelty/diversity;
- upset ability;
- lineage-specific objective;
- tactical sanity.

Do not collapse everything into one number unless selection specifically needs one.

---

# 13. Reproducibility
Every result must be traceable to:
- engine commit hash;
- rules version;
- genome IDs;
- seeds;
- tournament manifest;
- adjudication version;
- search depth/beam width;
- time controls;
- output schema version.

Never report simulated numerical results unless they were actually executed and saved.

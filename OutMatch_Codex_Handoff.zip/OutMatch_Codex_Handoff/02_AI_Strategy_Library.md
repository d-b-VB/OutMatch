# OutMatch AI Strategy Library

**Status: current design vocabulary, not game rules.**

## 1. AI architecture
A sophisticated general should be decomposable into several layers rather than one monolithic score.

### A. Recruitment doctrine
Chooses the hidden odd-round commitment.

### B. Perception
Classifies the board: threats, material/unit advantage, local force, viable flank, exposed pieces, shared risk, formation shape, enemy composition, and tempo.

### C. Interpretation
Determines what the perceived state means.  Example: an “open flank” may be a true opportunity, irrelevant empty space, or bait.

### D. Opponent model
Estimates how a particular opponent is likely to respond.  This can range from a coarse archetype classifier to a learned history of a named opponent.

### E. Strategic policy
Selects formation and maneuver preferences and evaluates candidate actions.

### F. Tactical sanity / reply awareness
Before accepting a move, tests whether the opponent has an obvious reply that makes the move nonsensical.  This layer is especially important because earlier Scipio versions could sacrifice Cavalry on move one.

### G. Historical learning
Some descendants study their lineage's past states and alter behavior to avoid recurring losing trajectories or preserve reliably winning ones.

These layers should be independently configurable and evolvable.

---

# 2. Recruitment doctrines

## Balanced
Attempts to maintain a mixed army.  Useful as baseline and as a stabilizer for otherwise biased genomes.

## Direct counter
Responds to enemy composition:
- Pikeman counters Cavalry.
- Archer counters Pikeman.
- Cavalry counters Archer.

This relation is strategic, not an absolute combat rule.

## Ratio counter
Weights a counter by both enemy abundance and the current shortage of the countering unit.  Historically this often produced better mixtures than simple plurality response.

## Balance/counter blend
Mixes a balanced target composition with reactive counter-production.  Variants such as 50/50 and 75%-counter were used successfully in early abstract tests.

## Lineage-biased recruiting
Examples:
- Parthian/Surena: Archer heavy.
- Genghis/Mongol: Cavalry heavy.
- Hannibal: Cavalry baseline with strong balancing/ratio response.
- Scipionic lines: typically mobile/Cavalry-inclined but not necessarily pure Cavalry.
- Paullus anti-Scipio lines: heavier Pikeman/Archer tendency.
- Emu: Cavalry-heavy, irregular.

## Contrarian / disadvantaged-unit
Historical experimental families deliberately chose unusual or “wrong” responses to preserve diversity.  Retain such doctrines as wild-card genes.

## Historical recruitment adjustment
A historian may suppress a unit type associated with family losses or reinforce a type associated with recoveries, but only when sample evidence is adequate.

### Caution
Correlation is not causation.  A lineage may have “many Pikemen in losses” because it recruited Pikemen in response to already losing positions.  Dunce historians are useful controls because occasionally the opposite interpretation performs better.

---

# 3. Formation vocabulary

Formations are **soft evaluation goals**, never legality constraints.

## Screen
Protect valuable rear units, commonly Archers, with Pikemen or other bodies toward the enemy.

## Layered
Multiple defensive/attacking ranks, usually preserving mutual support without becoming a single block.

## Phalanx
Tight Pikeman-centered mutual support.  Useful against Cavalry but vulnerable to becoming slow/static if overused.

## Wide
Spread laterally, usually to create Cavalry routes, threaten wings, or resist encirclement.

## Reserve
Keep a mobile or valuable unit behind the front for counterattack rather than initial commitment.

## Loose
Low-cohesion dispersion.  Often risky, but useful for irregular/barbarian/wild-card strategies and avoiding clustered threats.

## Kite
Maintain distance and preserve ranged units, yielding space while forcing pursuit.

## Wedge
Concentrate forward pressure into a narrower attacking structure.

### Formation metrics worth implementing
- adjacency/support graph;
- pike-pike adjacency;
- pike-in-front-of-archer screening;
- reserve depth;
- lateral width;
- distance to enemy;
- local numerical superiority;
- escape routes;
- Cavalry lanes;
- vulnerability to a single enemy activation.

---

# 4. Maneuver vocabulary

## Hold
Preserve position/shape; do not interpret as “do nothing forever.”

## Advance
Improve forward position without necessarily seeking immediate capture.

## Flank
Shift mobile force toward a side to attack a wing/rear or force a response.

## Counter-flank
Meet or blunt an enemy flank while preserving the center.

## Kite
Withdraw/shift to preserve distance while maintaining threats.

## Collapse
Concentrate force on an exposed or locally inferior enemy element.

## Charge
Accept elevated exposure for immediate tactical/tempo gain.

## Reform
Prioritize restoring support, screens, reserves, or safe geometry.

## Feint
Present an apparent threat or route to induce a response, without intending to commit along that line.

## Committed action / threat saturation
Key strategic insight: counting every threatened friendly as an independent risk is wrong.

If multiple friendlies are threatened by the **same** enemy unit, and that enemy can capture only one next turn, exposing another friendly may add little or no actual casualty risk.

Recommended metric:
- Build a bipartite graph:
  - left: friendly units that could be killed next enemy turn;
  - right: enemy units/activations capable of killing them;
  - edges: legal capture possibilities.
- Estimate enemy maximum captures by maximum matching or a more exact activation-sequence solver.
- Evaluate a candidate move by **delta in enemy kill capacity**, not raw threatened-piece count.

A committed charge is attractive when:
1. some loss is already unavoidable;
2. additional exposed pieces are threatened by the same limited enemy activations;
3. enemy maximum captures does not increase much;
4. the new position creates several threats, breaks a formation, or wins tempo.

---

# 5. Perception and interpretation

## Threat perception
Use exact `canCaptureInActivation` logic.  Do not use Archer distance 2 as a proxy for actual shooting.

## Viable flank perception
Earlier AI overreacted to “empty space on one side.”  A flank should require:
- reachable valuable target or positional objective;
- traversable route under Pike stop zones;
- enough local force;
- acceptable cost to center defense;
- useful timing.

## Quiet losing state
A recurring historical failure: a general can be slightly behind, unthreatened, with no immediate captures, and remain in a stable losing equilibrium.  Such states should trigger controlled attempts to create contact/volatility.

## Advantage conversion
A real unit lead should usually be preserved, but this is not universal.  The first Sun Tzu Academy overgeneralized conservatism and harmed strong Scipionic lines.  Tempo and initiative may remain valuable while ahead.

---

# 6. Opponent modeling

Potential levels:

### Level 0: board only
No named opponent assumptions.

### Level 1: archetype inference
Infer “Agrippan,” “Parthian,” “Mongol/mobile,” “reckless,” etc. from composition and geometry.

### Level 2: policy-response prediction
Estimate “If I show this flank, this opponent tends to widen/reform/kite.”

### Level 3: named-opponent history
Use recorded games against the exact opponent to estimate response probabilities.

### Level 4: second-order deception
Reason about the opponent's model:
“You think I am acting like Agrippa, so you will invoke Marc-Antony logic; therefore I should choose the line that punishes Marc.”

Future `Thrawn` should be reserved for a general whose defining strength is this historical opponent-modeling approach.

---

# 7. Tactical sophistication upgrades
Priority upgrades:
1. Opening-book sanity check for obviously hanging a piece.
2. Exact immediate-reply tactical check.
3. Whole-turn beam search over activation sequences.
4. One-reply minimax or opponent best-response approximation.
5. Exact kill-capacity matching.
6. Transposition/memoization for repeated states.
7. Learned position/value models only after exact rule tests exist.

Do not “improve” a general by replacing its distinctive policy wholesale.  Add sophistication layers in a way that preserves lineage identity so sibling comparisons remain meaningful.

# OutMatch Simulation Engineering, Repository, and Logging

## 1. Repository architecture
Recommended:

```
outmatch/
  README.md
  docs/
  rules/
    rules_engine.*
    fixtures/
    tests/
  ai/
    genome_schema.json
    perception/
    evaluation/
    search/
    recruiting/
  generals/
    canonical/
    generations/
  simulation/
    tournament_runner.*
    scheduler.*
    parallel.*
  analysis/
    rankings.*
    matchups.*
    histories.*
    lineage.*
  web/
    playable/
  replays/
    schema/
  results/
```

The exact language is open.  Performance should drive the headless engine choice.  Browser UI can remain JavaScript/TypeScript while sharing rule fixtures and ideally generated policy data.

---

# 2. Performance target
The project needs to compare several hundred competitors using fully simulated legal games.

Target:
- hundreds of thousands to millions of games per experimental campaign;
- millisecond to low-tens-of-milliseconds average game where feasible;
- multicore parallelism;
- deterministic reproducibility.

Profile before optimizing.

Likely optimizations:
- integer-index the 37 board cells;
- precompute neighbor lists, distances, ray/path structures, base distances;
- compact bitboards or small fixed arrays for occupancy;
- precompute Pike-zone relationships;
- memoize Cavalry reachability by local occupancy if effective;
- avoid object allocation in inner loops;
- incremental evaluation;
- transposition table;
- batch/parallel games;
- separate “summary logging” from expensive full trace logging.

---

# 3. Exact rules tests
Create exhaustive regression fixtures for:
- every starting position;
- Pikeman move/capture;
- Archer shoot before move;
- Archer move then shoot;
- Archer cannot shoot distance 2;
- Cavalry 1/2/3 movement;
- Cavalry passing through friendly;
- Cavalry cannot end on friendly;
- Cavalry captures and stops;
- Cavalry cannot pass enemy;
- Pike stop-zone entry allowed;
- Pike stop-zone continuation forbidden;
- hidden recruitment;
- odd commitment/even deployment;
- newly deployed unit inactive;
- blocked-deployment queue persistence;
- elimination victory.

The same fixtures should be runnable against headless and browser engines.

---

# 4. Search sophistication
Older simulations were greedy one-activation-at-a-time evaluators.  This is insufficient for strong play.

Recommended progression:

## Level 1: immediate tactical sanity
Before selecting a move, test obvious opponent captures.  Prevent gratuitous opening sacrifices such as the observed Scipio Cavalry blunder.

## Level 2: whole-turn beam search
Search sequences of activations because order matters.
Suggested beam width initially 8-20.

## Level 3: opponent reply
For each candidate completed turn, approximate or search the opponent's best turn.

## Level 4: shallow minimax / selective extension
Extend forcing capture sequences and high-risk committed actions.

Use sophistication as an evolvable/general parameter only after there is a fair baseline.  More compute should not automatically be interpreted as “better doctrine.”

---

# 5. Evaluation metrics
Prefer interpretable features:
- unit count;
- exact composition;
- immediate legal captures;
- enemy exact legal captures;
- maximum capture/kill capacity;
- threatened units;
- support graph;
- screens;
- mobility;
- safe escape squares;
- local superiority;
- advancement/tempo;
- recruitment queue state (own only);
- uncertainty about opponent queue.

Avoid opaque “material” terminology in user-facing analysis.  Internally, if using approximate piece values, record them explicitly.  Earlier analysis used:
- Pikeman 100
- Archer 105
- Cavalry 110

Those numbers are heuristic and should not be presented as game economics or proven piece values.

---

# 6. Genome persistence
Every general must have an immutable machine-readable genome.

Example fields:
```json
{
  "id": "gen_0042_019",
  "name": "Hannibal",
  "rules_version": "1.0",
  "parents": ["wild_0017"],
  "generation": 12,
  "seed": 883921,
  "recruitment": {},
  "perception": {},
  "policy": {},
  "search": {},
  "history_model": null,
  "tags": ["wildcard-origin", "hannibalic"]
}
```

Never reconstruct an important general from prose if the original genome can be stored.

---

# 7. Tournament output
Minimum per-game summary:
- game ID;
- rules/engine version;
- Red genome ID;
- Blue genome ID;
- seed;
- winner;
- elimination vs adjudication;
- rounds;
- final composition;
- final board hash;
- optionally first decisive swing.

Tournament outputs:
- ranking table;
- color-adjusted rates;
- pairwise matrix;
- confidence intervals;
- lineage summary;
- upset list;
- target-assassin table;
- diversity/cluster analysis.

---

# 8. Detailed game trace schema
For selected games and all human games, log:

## Header
- replay/game ID
- timestamp
- rules version
- engine version
- Red player/general ID
- Blue player/general ID
- human/AI flags
- random seed
- initial state

## Every event
- round
- side
- event type
- unit ID/type
- from/to
- capture/shot target
- recruitment commitment
- deployment
- full or reconstructible board state
- legal actions if doing postgame decision analysis

## AI decision metadata (optional heavy mode)
- perceived state;
- opponent classification;
- top candidate actions;
- scores;
- tactical reply score;
- search depth;
- chosen action.

---

# 9. Human-friendly replay logging
Phone download/copy proved unreliable.  Logging should therefore be redundant and foolproof.

Recommended browser behavior:
1. Auto-save every game to IndexedDB/local storage.
2. Keep multiple completed games.
3. Generate a compact deterministic replay code from events, not repeated full board snapshots.
4. Provide native Web Share API:
   - `navigator.share({files:[...]})` where supported;
   - text share fallback.
5. Provide one-tap copy.
6. Always show the replay code in a selectable large text area as last-resort fallback.
7. Permit “Share all games” as one compact file.
8. Optionally encode a short session into a QR code for transfer to another device.
9. Allow import/paste of replay code to reproduce the game.

A replay can be compact because the initial board and rules are deterministic.  Store only commitments/deployments/actions/results plus version identifiers.

---

# 10. Human lineage
Human games become strategic training data.

Reserved names:
- `Philip`: first general derived from the user's observed play.
- `Aristotle`: analyst/trainer that repeatedly studies the human archive and revises the second-generation human-derived policy.

For every human decision:
- reconstruct legal alternatives;
- evaluate what each established general would have chosen;
- identify novel actions;
- identify recurring tactical strengths/blunders;
- compare outcome trajectories.

Do not force Philip to imitate superficial frequencies.  Preserve distinctive human decisions that outperform AI alternatives.

---

# 11. Codex operating guidance
Codex should:
- modify the repository, not transient notebooks;
- benchmark before/after performance changes;
- maintain tests;
- persist genomes/results;
- produce manifests for every tournament;
- never silently change canonical rules to improve AI;
- label experimental evaluator changes;
- prefer partial reproducible experiments over unverifiable large claims.

# OutMatch Codex Handoff

## Purpose
This package is intended to let Codex continue development of **OutMatch**, a compact hex-board tactical strategy game and an evolving ecology of AI generals.  The project began as the tactical combat component of a larger prototype formerly called UpKeep; the current game should be called **OutMatch**.  The economic/building systems associated with the old name are not part of this project.

## Source-of-truth order
When documents disagree, use this order:

1. `01_OutMatch_Game_Spec` — canonical game rules.
2. `05_Simulation_Engineering_and_Logging` — canonical engineering and reproducibility requirements.
3. `02_AI_Strategy_Library` — current AI vocabulary and design space; revisable.
4. `03_Generals_Lineages_Roster` — current named strategy families and historical context; revisable.
5. `04_Evolution_Experimentation_Strategy` — experimental methodology; revisable as evidence accumulates.
6. `06_Continuation_Brief` — current priorities and open questions.

Older browser files and CSVs may contain obsolete AI evaluators or temporary rules.  They are evidence and fixtures, not authority.

## Core project goals
- Preserve the game as a very small, legible ruleset.
- Make AI behavior deep through policy, perception, opponent modeling, and evolution rather than through rule exceptions.
- Run hundreds of competitors and eventually millions of fully simulated games reproducibly.
- Maintain a diverse ecology: champions, respectable middle-tier generals, specialists/assassins, weak fodder, crossbreeds, historians, deliberate bad learners, and fresh wild cards.
- Analyze why strategies work, not only their aggregate win rate.
- Record human games in a replayable format and use them as a new strategic lineage.

## Naming conventions
- The game is **OutMatch**.
- Existing historical/fictional general names may continue to label AI strategies.
- **Macedonian names are reserved for the human-derived lineage.**
  - `Philip` = Generation 1 general modeled on the user's actual play.
  - `Aristotle` = analyst/trainer that repeatedly studies human games and revises Generation 2 until the result is satisfactory.
  - Avoid using Alexander, Parmenion, Antipater, etc. for unrelated AI lines unless this policy is later changed.

## Deliverables Codex should establish
A repository should contain:
- exact headless rules engine;
- browser/playable client using the same rules and tests;
- general genome/policy files with immutable IDs and lineage metadata;
- tournament runner supporting hundreds of competitors;
- reproducible seeds/manifests;
- game and replay logging;
- analysis scripts;
- regression tests for every canonical rule;
- retained historical results.

## Important caution
Several earlier simulations used greedy/pruned evaluators and approximate threat logic.  Never assume an old ranking means optimal play.  A known example: an earlier Scipio implementation could send cavalry out to die pointlessly on the opening move, while still scoring highly in simulated fields.  Human inspection exposed the flaw.  Tactical sanity and reply-aware evaluation must be part of future engines.

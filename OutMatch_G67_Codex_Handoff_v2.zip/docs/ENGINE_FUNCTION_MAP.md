# Current genome-to-move function map

All function names below are in `current/CURRENT_PLAYABLE_ENGINE_EXACT.js`.

## Recruitment
- `recruitScores(g, side, genome)`
  - Reads `recruitBase`, `recruitResponse`, and `desiredRatio`.
- `aiRecruit(g, side, genome)`
  - Picks the maximum-scoring unit type.

## Deployment
- `deploymentSpots(g, side)`
- `aiDeploy(g, side, genome)`
  - Reads the `deploy` genes: `center`, `enemyBase`, `support`, `exposure`.

## Legal movement / combat
Use the playable's exact legal-move/action functions. Do not reimplement from an older ruleset.

## Tactical evaluation
- `featureScore(...)`
  - Converts a board transition/action into a genome-dependent score.
- `orderedCandidateActions(...)`
  - Candidate breadth is capped at 8 and is affected by `search.exploration` and `search.ordering`.
- `actionIncrement(...)`
  - Adds sequence effects including `secondAction`, `sameUnitCombo`, `coordinatedCombo`, and `doubleCapture`.
- `lookahead(...)`
- `lookaheadAsync(...)`
  - Depth-3 receding-horizon search.
  - Carried beam cap is 4.
- `runAITurn()`
  - Replans after each activation.

## End state
- `material(g)` uses P=100, A=105, C=110.
- `pressure(g)` is used only after material and captured-material tie-breaks at the round cap.

The full implementation, rather than this map, is authoritative.
